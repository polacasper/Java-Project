/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import static javaprojectfxml.RegisterClass.con;
import static javaprojectfxml.RegisterClass.connectStart;
import static javaprojectfxml.RegisterClass.pst;

/**
 *
 * @author Pola Casper
 */
public class FXMLDocumentController implements Initializable {
    
    
   static Connection con;
   static PreparedStatement pst2;
   static ResultSet rs2;
   static String name;
   static String pass;
   public static String[] namesArray;
   public static String[] passArray;
   static int k;
   static boolean existFlag = false;
   private static boolean returnVal = true;
   private static boolean returnVal2 = true;

    private static boolean soundFlag = true;
    public boolean sign;
    public boolean lock00, lock01, lock02, lock10, lock11, lock12, lock20, lock21, lock22;

    public static String savedUsername;
    public static int conResponse;
    
    public ClientSideSocket socketLogin;
    
    @FXML
    private Button single, multi, load, hall, settings, logout, back, back2, sound, label, signin, signup, newgame, easy, cancel, confirm;    
    
    @FXML
    private ImageView X1, X2, X3, X4, X5, X6, X7, X8, X9;
    
    @FXML
    private ImageView O1, O2, O3, O4, O5, O6, O7, O8, O9;
            
    @FXML
    private TextField username, newuser;
    
    @FXML
    private PasswordField password, newpassword, newpassword2;
    
    
    @FXML
    private VBox vbox;
    
    @FXML
    private Button b1, b2, b3, b4, b5, b6, b7, b8, b9;
    
    @FXML
    private Label label1, label2, label3, label4, label5, label6, label7, label8, label9, labelresult, warning, warning2;
    
    @FXML 
    private TableView<String> playerlist;
    
    @FXML 
    public static TableColumn playername;
    
    @FXML 
    private TableColumn status;
    
    @FXML 
    private TableColumn choose;
    
    Stage stage;
    Parent root;

    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        if (event.getSource() == signin) {
//            LoginClass.connectStart();
            savedUsername = username.getText();
            if(username.getText().isEmpty() || password.getText().isEmpty())
            { 
                System.out.println("Empty entry!");
                warning.setText("Please enter username and password.");
            }
                    
            else{    
                String sendToServer = "login," + username.getText().trim().toString()+ "," + password.getText().trim().toString();
                socketLogin = new ClientSideSocket();
                socketLogin.toServer(sendToServer);
            }
            
//                    LoginClass.login(username.getText(), password.getText());
//            }
//            {
//            stage = (Stage) signin.getScene().getWindow();
//            root = FXMLLoader.load(getClass().getResource("Play.fxml"));
//            }
//            else if(username.getText().isEmpty() || password.getText().isEmpty())
//            {
//                System.out.println("Empty entry!");
//                warning.setText("Please enter username and password.");
//            }
//            else
//            {
//                System.out.println("Wrong entry");
//                warning.setText("Wrong username or password.");
//            }
//            
        }else if (event.getSource() == signup) {
            stage = (Stage) signup.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Register.fxml"));
        }else if (event.getSource() == confirm) {
            warning2.setText("");
            System.out.println(newuser.getText()+"lllll");
            if (newuser.getText().isEmpty() || newpassword.getText().isEmpty() || newpassword2.getText().isEmpty()){warning2.setText("Empty Fields! Please fill all fields.");}
            else if (newuser.getText().contains(",") || newuser.getText().contains(";") || newuser.getText().contains("&") || newuser.getText().contains("!") || newuser.getText().contains("<") || newuser.getText().contains(">") || newuser.getText().contains("^") || newuser.getText().contains("/") || newuser.getText().contains("\\")){warning2.setText("Username or Password can not contain special charachter (, ; \\ / < > ! & ^)");}
            else if (newpassword.getText().contains(",") || newpassword.getText().contains(";") || newpassword.getText().contains("&") || newpassword.getText().contains("!") || newpassword.getText().contains("<") || newpassword.getText().contains(">") || newpassword.getText().contains("^") || newpassword.getText().contains("/") || newpassword.getText().contains("\\")){warning2.setText("Username or Password can not contain special charachter (, ; \\ / < > ! & ^)");}
            else if (Objects.equals(newpassword.getText(), newpassword2.getText())== false){warning2.setText("Passwords don't match! Please reenter your passwords.");}
            
            else if (checkUsername(newuser.getText()) == false)
                {
                    warning2.setText("");
                    System.out.println("okkkkkkkk");
                    warning2.setText("Username already exists! Please use another name or Go Back to login.");
                    newuser.setText("");
                }
            else //if (checkUsername(newuser.getText())== true)
                {
                    warning2.setText("");
                    RegisterClass.register(newuser.getText(), newpassword.getText(), newpassword2.getText());
                    savedUsername = newuser.getText();
                    stage = (Stage) confirm.getScene().getWindow();
                    root = FXMLLoader.load(getClass().getResource("Play.fxml"));
                }
        } else if (event.getSource() == cancel || event.getSource() == back2) {
            stage = (Stage) cancel.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        } else if (event.getSource() == single) {
            stage = (Stage) single.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Difficulty.fxml"));
        } else if (event.getSource() == easy) {
            stage = (Stage) easy.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        } else if (event.getSource() == multi) {
            stage = (Stage) multi.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Player2.fxml"));
        } else if (event.getSource() == load) {
            
        } else if (event.getSource() == back) {
            stage = (Stage) back.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Play.fxml"));
        } else if (event.getSource() == hall) {
            stage = (Stage) hall.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("PlayerList.fxml"));
        } else if (event.getSource() == logout) {
            LogoutClass.connectStart();
            LogoutClass.logout(savedUsername);
            LogoutClass.connectClose();
            stage = (Stage) logout.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        } else if (event.getSource() == newgame) {
            stage = (Stage) newgame.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        }

        //create a new scene with root and set the stage
        if (root != null) {
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    public void Game(ActionEvent event) throws RuntimeException {
        if (event.getSource() == b1 && !lock00) {
            System.out.println("b1");
            if (sign == true) {
                label1.setText("O");
                O1.setVisible(true);
                sign = false;
                lock00 = true;
            } else {
                label1.setText("X");
                X1.setVisible(true);
                sign = true;
                lock00 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b2 && !lock01) {
            System.out.println("b2");
            if (sign == true) {
                label2.setText("O");
                O2.setVisible(true);
                sign = false;
                lock01 = true;
            } else {
                label2.setText("X");
                X2.setVisible(true);
                sign = true;
                lock01 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b3 && !lock02) {
            System.out.println("b3");
            if (sign == true) {
                label3.setText("O");
                O3.setVisible(true);
                sign = false;
                lock02 = true;
            } else {
                label3.setText("X");
                X3.setVisible(true);
                sign = true;
                lock02 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b4 && !lock10) {
            System.out.println("b4");
            if (sign == true) {
                label4.setText("O");
                O4.setVisible(true);
                sign = false;
                lock10 = true;
            } else {
                label4.setText("X");
                X4.setVisible(true);
                sign = true;
                lock10 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b5 && !lock11) {
            System.out.println("b5");
            if (sign == true) {
                label5.setText("O");
                O5.setVisible(true);
                sign = false;
                lock11 = true;
            } else {
                label5.setText("X");
                X5.setVisible(true);
                sign = true;
                lock11 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b6 && !lock12) {
            System.out.println("b6");
            if (sign == true) {
                label6.setText("O");
                O6.setVisible(true);
                sign = false;
                lock12 = true;
            } else {
                label6.setText("X");
                X6.setVisible(true);
                sign = true;
                lock12 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b7 && !lock20) {
            System.out.println("b7");
            if (sign == true) {
                label7.setText("O");
                O7.setVisible(true);
                sign = false;
                lock20 = true;
            } else {
                label7.setText("X");
                X7.setVisible(true);
                sign = true;
                lock20 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b8 && !lock21) {
            System.out.println("b8");
            if (sign == true) {
                label8.setText("O");
                O8.setVisible(true);
                sign = false;
                lock21 = true;
            } else {
                label8.setText("X");
                X8.setVisible(true);
                sign = true;
                lock21 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b9 && !lock22) {
            System.out.println("b9");
            if (sign == true) {
                label9.setText("O");
                O9.setVisible(true);
                sign = false;
                lock22 = true;
            } else {
                label9.setText("X");
                X9.setVisible(true);
                sign = true;
                lock22 = true;
            }
            success('X');
            success('O');
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
//        playername.cellValueFactoryProperty(new PropertyValueFactor<Person, String>("test"));
    }

//    private List parsePlayerList(){
//        
//        return List;
//    }
    public void success(char ch) {
        if (ch == label1.getText().charAt(0)) {
            if (ch == label2.getText().charAt(0) && ch == label3.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            } else if (ch == label4.getText().charAt(0) && ch == label7.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            } else if (ch == label5.getText().charAt(0) && ch == label9.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            }
        }
        if (ch == label9.getText().charAt(0)) {
            if (ch == label3.getText().charAt(0) && ch == label6.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            } else if (ch == label8.getText().charAt(0) && ch == label7.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);            }
        }
        if (ch == label5.getText().charAt(0)) {
            if (ch == label3.getText().charAt(0) && ch == label7.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            } else if (ch == label2.getText().charAt(0) && ch == label8.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            } else if (ch == label4.getText().charAt(0) && ch == label6.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b1.setDisable(true);
                b2.setDisable(true);
                b3.setDisable(true);
                b4.setDisable(true);
                b5.setDisable(true);
                b6.setDisable(true);
                b7.setDisable(true);
                b8.setDisable(true);
                b9.setDisable(true);
            }
        }
    }
    
    public static boolean checkUsername(String newUsername)
    {
        returnVal2=true;
        try {
            try {
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "postgres");
                System.out.println("OK Start");
                } catch (SQLException ex) {
                Logger.getLogger(RegisterClass.class.getName()).log(Level.SEVERE, null, ex);
                }
            
               pst2 = con.prepareStatement("Select count(playername) from tictactoe",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
               rs2 = pst2.executeQuery();
               
               if(rs2.next()){k = rs2.getInt(1);}
               System.out.println("Count(playername) = "+k);
               
               namesArray = new String[k];
               pst2 = con.prepareStatement("Select playername from tictactoe",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
               rs2 = pst2.executeQuery();
               int i=0;
               while(rs2.next())
               {
                   name = rs2.getString(1);
                   namesArray[i]=name;
                   System.out.println(namesArray[i]);
                   i++;
               }
           } catch (SQLException ex) {
               Logger.getLogger(LoginClass.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           for(String names : namesArray)
               System.out.println(names);
           
           for(String str : namesArray)
           {
               if (str.equals(newUsername))
               {
                   returnVal2 = false;
                   break;
               }
           }
//        RegisterClass.connectClose();
        return returnVal2;
    }
}
