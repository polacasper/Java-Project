/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
//import serversidesocket.SocketHandler;

/**
 *
 * @author ITI
 */
public class ServerSideSocket {

    ServerSocket myServerSocket;
    Socket s;
//    Socket s;
//    DataInputStream dis;
//    PrintStream ps;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
       ServerSideSocket sss= new ServerSideSocket();       
    }
        
    public ServerSideSocket(){
        try {
            myServerSocket=new ServerSocket(5005);
                while(true){            
                    s = myServerSocket.accept();
                    SocketHandler2 sh = new SocketHandler2(s);
                    SocketHandler2.x=SocketHandler2.x+10;
                }
            } catch (IOException ex) {
                Logger.getLogger(ServerSideSocket.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
    public void closeServerSocket(){
        try {
            this.myServerSocket.close();
        } catch (IOException ex) {
            Logger.getLogger(ServerSideSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
