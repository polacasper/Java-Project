/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import static project.DoPlay.moves;
//import static project.Play.moves;

/**
 *
 * @author Abdel-Rahman
 */
public class DoPlay {
   
           
   static Connection con;
   static PreparedStatement pst;
   public static String moves = "";// Play.moves;
//   DoPlay.moves = 
    public static int getid(String str){
        String[] fields= str.split(",");
        //String field1= fields[0];
        int field2= Integer.parseInt(fields[1]);
        //int field3= Integer.parseInt(fields[2]);
        //char field4= fields[3].charAt(0);    why we need this ????????????????????????
        //int field5= Integer.parseInt(fields[4]);
        //System.out.println(field1);
        //System.out.println(field2);
        //System.out.println(field3);
        //System.out.println(field4);
        //System.out.println(field5);
        return field2;
    } // ready to put it in game table for the first time (insert into table)
    
    public static int getremotid(String str){
        String[] fields= str.split(",");
        int field3= Integer.parseInt(fields[2]);
        return field3;
    } // ready to put it in game table for the first time (insert into table)
    
     public static String getcell(String str){
        String[] fields= str.split(",");
        String field5 = fields[4];
        return field5;
    } // ready to put it in game table for the first time (insert into table)
    
    public static void connectStart() throws SQLException
    {
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "postgres");
                System.out.println("OK Start");
    }
    
     public static void connectClose() throws SQLException
    {
           pst.close();
           con.close();
           System.out.println("OK Close");
    }
     
     public static void moves (String move){
        moves.concat(move);
        Play.moves=DoPlay.moves;
     }
     public static void record(int id, int remote, int moves ) throws SQLException{
        pst = con.prepareStatement("insert into game (player1, player2, date, record) values (?, ?, now(), ?) where   ",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//        String  string="";
//        int id1=Play.getid(str);
//        int remote1=Play.getremotid(str);
        pst.setInt(1,id);
        pst.setInt(2,remote);
        pst.setInt(3,moves);
        pst.executeUpdate();
//        return string;
     }
    
    /*public static void draw_o(String str){
        String[] fields= str.split(",");
        int field5= Integer.parseInt(fields[4]);
        String drawo="drawo"+","+field5;
        System.out.println(drawo);
        new Server.draw_o(drawo); //method in Server class that user1 socet and send in it string start with drawo wich activate listner wich has method draw X on UI
    }*/
}
