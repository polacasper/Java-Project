package javaprojectfxml;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package serversidesocket;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ITI
 */

public class SocketHandler2 extends Thread {
    public static int x=4;
    String str;
    DataInputStream dis;
    PrintStream ps;
//    static Vector<SocketHandler2> clientsVector =new Vector<SocketHandler2>();
    static ConcurrentMap<Integer, SocketHandler2> clientsContainer = new ConcurrentHashMap<Integer,SocketHandler2>();
    int index1,index2;
    SocketHandler2 clientsocket1;
    SocketHandler2 clientsocket2;
    
    public SocketHandler2(Socket s){
        int ID;
        try {
            dis=new DataInputStream(s.getInputStream());
            ps=new PrintStream(s.getOutputStream());
//            clientsVector.add(this);
//            ID=Server.getID(str);
//            DBmangement.setindex(clientsVectors.indexof(this),ID);
//            clientsContainer.put(ID, this);
            clientsContainer.put(x, this);
            
        new Thread(() -> {
            while(true){
                try {
                    str=dis.readLine() + "   " + x;
                    System.out.println(str);
                    
                } catch (IOException ex) {
                    Logger.getLogger(SocketHandler2.class.getName()).log(Level.SEVERE, null, ex);
                }                
            }
            }).start();
        start();
//        x+=10;
        } catch (IOException ex) {
            Logger.getLogger(SocketHandler2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   
    
    
    //to send the messages to the server class
    public  void sendToServer(String str){
        MainServer.msg=str;
    }
    
    
    public static void sendToClientSocket(int clientID){
        String ss=new MainServer().response;
        clientsContainer.get(clientID).ps.println(ss);
    }
    
    
    
    public  void connect(int client1ID, int client2ID){
//        int client1index=DBMangement.getIndex(client1ID);
//        int client2index=DBMangement.getIndex(client2ID);
//        clientsocket1 = clientsVector.get(client1ID);
//        clientsocket2 = clientsVector.get(client2ID) ;
//        System.out.println("From Client1" + clientsocket1.str);
//        System.out.println("From client2" + clientsocket2.str);                 
//        clientsocket2.ps.println("Server2A");
//        clientsocket1.ps.println("Server1A");
//        clientsocket2.ps.println("Server2B");
//        clientsocket1.ps.println("Server1B");
        clientsocket1=clientsContainer.get(client1ID);
        clientsocket2=clientsContainer.get(client2ID);

new Thread(new Runnable() {
            @Override
            public void run() {
                while (true){
//                clientsocket2.ps.println("from client1 " + clientsocket1.str );
                clientsocket1.ps.println("from client2 " + clientsocket2.str);
                }
            }
        }).start();
//        x+=10;               

    }
    
//    public int getClientIndex(int ID){
//        return DBMangement.getIndex(ID);
//    }
    
    @Override
    public void run(){
        connect(4,14);
        new MainServer().responseToClient("ok",4);
        MainServer.requestFromClient("sent from inner Server" + str);
    }
}

