/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SocketHandler;

/**
 *
 * @author Abdel-Rahman
 */
public class Server{
    static ServerSideSocket serverSocket;
     static SocketHandler2 testSocket = new SocketHandler2(serverSocket.s);
    
    public static void main(String[] args){
        serverSocket = new ServerSideSocket();
        try {
            redirect("");
        } catch (SQLException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void redirect(String str) throws SQLException, IOException{
        String[] fields = str.split(",");
        String field1 = fields[0]; 
        switch(field1) {
            case "login":
                String name;
                String password;
                boolean check;
                System.out.println("Tesssssssssssssssssssst");
//                name=Server.getusername(str);
//                password=Server.getuserpassword(str);
//                LoginClass.connectStart();
//                check=LoginClass.login(name,password);
//                LoginClass.connectClose();
//                ServerSideSocket.loginrespond(check);
            break;
            
            case "register":
                String name1;
                String password1;
                String password2;
                boolean check1;
                name1=Server.getusername(str);
                password1=Server.getuserpassword(str);
                password2=Server.getuserpassword2(str);
                RegisterClass.connectStart();
                check1=RegisterClass.register(name1,password1,password2);
                RegisterClass.connectClose();
//                ServerSideSocket.registerrespond(check1);
            break;
            
            case "getusers":
                
            break;
            
            case "invite":
                int remote,id;
                remote=Invite.getremotid(str);
                id=Invite.getid(str);
                testSocket.connect(id,remote);
            break;
            
            case "inviteresponse":
                //String response = fields[1];
                //boolean resp=Boolean.valueOf(response);
                //InviteResponse.response();
                //Server.respond();
                int remote1,id1;
                remote1=InviteResponse.getremotid(str);
                id1=InviteResponse.getid(str);
//                SocketHandler.connect(id1,remote1);
            break;
            
            case "play":
                int id2;
                int remote2;
                String cell;
                Play.connectStart();
                id2=Play.getid(str);
                remote2=Play.getremotid(str);
                cell=Play.getcell(str);
                Play.moves(cell);
//                SocketHandler.connect(id2,remote2);
                Play.connectClose();
                
            break;
            
            case "doplay":
                int id3;
                int remote3;
                String cell2;
                DoPlay.connectStart();
                id2=DoPlay.getid(str);
                remote2=DoPlay.getremotid(str);
                cell=DoPlay.getcell(str);
                DoPlay.moves(cell);
                DoPlay.connectClose();
//                SocketHandler.connect(id3,remote3);
            break;
            
            case "logout":
                String name2;
                LogoutClass.connectStart();
                name2=Server.getusername(str);
                LogoutClass.logout(name2);
                LogoutClass.connectClose();

            break;
        }
    }
    
    public static String getusername(String str){
        String[] fields = str.split(",");
        String name = fields[1];
        return name;
    }
    
    public static String getuserpassword(String str){
        String[] fields = str.split(",");
        String password = fields[2];
        return password;
    }
    
    public static String getuserpassword2(String str){
        String[] fields = str.split(",");
        String password = fields[3];
        return password;
    }
    //public static void respond(){
        
    //}
}