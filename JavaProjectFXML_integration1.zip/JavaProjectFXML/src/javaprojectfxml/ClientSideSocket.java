/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author ITI
 */
public class ClientSideSocket {
    Socket s;
    PrintStream ps;
    DataInputStream dis;
    String receivedString, sendMsg;
    public ClientSideSocket(){
        try {
            s = new Socket("127.0.0.1",5005);
            dis = new DataInputStream(s.getInputStream());
            ps = new PrintStream(s.getOutputStream());
            new Thread(() -> {
                            while(true)
                            {
                                try{
                                    receivedString=dis.readLine();
                                    fromServer();
                                }catch(IOException ex){}
                            }
                }).start();
        } catch (IOException ex) {
            Logger.getLogger(ClientSideSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
    
//        this.toServer(msg);
        
    }

//    ClientSideSocket() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
    public void clientClose(){
        try {
            this.ps.close();
            this.dis.close();
            this.s.close();
        } catch (IOException ex) {
            Logger.getLogger(ClientSideSocket.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void fromServer(){
           
        System.out.println(receivedString);        
//        reci
//        String returnedMsg;
//        if(s.startsWith("login")){ 
////            textfeild="logged in successfully"
//                return "true";
//        }else if(s.startsWith("register")){
//        
//        }else if(s.startsWith("play")){
//        
//        }
//        
    }
    
    public void toServer(String sendMsg){
        
        ps.println(sendMsg);
        
    }
    
//   public static void main(String[] args){
//       ClientSideSocket css=new ClientSideSocket();
//        css.toServer("test message from client to server");
//////        css.clientClose();
//////        css2.clientClose();
//    }
    
}
