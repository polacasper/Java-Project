/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

/**
 *
 * @author Abdel-Rahman
 */
// 1- receive the boolean from socet manager (from user2)
// 2- send the boolean to socet manager (to user1)
public class InviteResponse {

    /**
     *
     * @param str
     * @return 
     */
    
    public static int getremotid(String str ){
        String[] fields = str.split(",");
        int field3 = Integer.parseInt(fields[2]);
        return field3;
    }
    
    public static int getid(String str ){
        String[] fields = str.split(",");
        int field2 = Integer.parseInt(fields[1]);
        return field2;
    }
    
    // object.response(true);
    //public static void response(){
        //if(response==true) {
            //Server.respond(); //method in Server class wich get user1 socet and send in it boolean has true
        //}
        //else if(response==false) {
            //Server.declined();//method in Server class wich get user1 socet and send in it boolean has false
        //} 
        // then Client class recive the boolean and use if condition whether to appear the game UI or declined message
}

