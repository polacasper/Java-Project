/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.util.StringTokenizer;

/**
 *
 * @author ITI
 */
public class MainServer {
    public static String msg;
    static String response="yaraaaaaaaaaaaab";
//    public  void setMsg(String socketMsg){
//        msg=socketMsg;
//    }
    
//    public MainServer(){
//               ServerSideSocket sss= new ServerSideSocket();
//               msg=null;

//    }
    
    private  void seperate(String request)
	{
		StringTokenizer st = new StringTokenizer(request,",");
		while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken());	
		}
	}
    
    public static void requestFromClient(String req){
        String req_received=req;
        System.out.println(req_received);
    }
    
    public void responseToClient(String ServerReturnValue,int clientID){
//        response=ServerReturnValue;
        response="Successfully done from new class";
        SocketHandler2.sendToClientSocket(clientID);
    }
    public static void main(String[] args){
//            
                    new ServerSideSocket();
                    
                    MainServer ms=new MainServer();
                    ms.responseToClient("ok",4);
    }
}
