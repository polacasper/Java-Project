/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author Pola Casper
 */
public class FXMLDocumentController implements Initializable {
    public boolean sign;
    public boolean lock00, lock01, lock02, lock10, lock11, lock12, lock20, lock21, lock22;
    
    
    @FXML
    private Button single;
    @FXML
    private Button multi;
    @FXML
    private Button hall;
    @FXML
    private Button settings;
    @FXML
    private Button logout;
    @FXML
    private Button back;
    @FXML
    private Button sound;
    @FXML
    private Label label;
    @FXML
    private Button signin;
    @FXML
    private Button signup;
    @FXML
    private Button easy;
    @FXML
    private Button b00, b01, b02, b10, b11, b12, b20, b21, b22;
    @FXML
    private Label label00, label01, label02, label10, label11, label12, label20, label21, label22;
    
    Stage stage;
    Parent root;
    public boolean soundFlag=true;
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException{
     if(event.getSource()==signin){
        stage=(Stage) signin.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Play.fxml"));
      }
     else if(event.getSource()==single){
        stage=(Stage) single.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Difficulty.fxml"));
      }
     else if(event.getSource()==easy){
        stage=(Stage) easy.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Game.fxml"));
      }
     else if(event.getSource()==multi){
        stage=(Stage) multi.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Player2.fxml"));
      }
     else if(event.getSource()==back){
        stage=(Stage) back.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Play.fxml"));
      }
     else if(event.getSource()==hall){
        stage=(Stage) hall.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("PlayerList.fxml"));
      }
     else if(event.getSource()==settings){
        if(soundFlag)
        {
            label.setText("Sound on");
            System.out.println(soundFlag);
        }
        else if(!soundFlag)
        {
            label.setText("Sound off");
            System.out.println(soundFlag);
        }
         stage=(Stage) settings.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
      }
     else if(event.getSource()==sound){
         soundFlag=!soundFlag;
        if(soundFlag)
        {
            label.setText("Sound on");
        }
        else if(!soundFlag)
        {
            label.setText("Sound off");
        }
        stage=(Stage) sound.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
         
//         if(label.getText().toString().trim()=="Sound on"){
//            label.setText("Sound off");
//            stage=(Stage) sound.getScene().getWindow();
//            root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
//           // sound.getScene().setRoot(root);
//
//         }
//         if(label.getText().toString().trim()=="Sound off"){
//            label.setText("Sound on");
//            stage=(Stage) sound.getScene().getWindow();
//            root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
////        sound.getScene().setRoot(root);
//         }

     }
     else if(event.getSource()==logout){
        stage=(Stage) logout.getScene().getWindow();
        root = FXMLLoader.load(getClass().getResource("Login.fxml"));
      }
     
     //create a new scene with root and set the stage
      Scene scene = new Scene(root);
      stage.setScene(scene);
      stage.show();
    }
    
    
     @FXML
    public void Game(ActionEvent event) throws RuntimeException{
      if(event.getSource()==b00&&!lock00){
         System.out.println("b00");
         if(sign==true)
            {
                label00.setText("O");
                sign=false;
                lock00=true;                
            }
         else 
         {
             label00.setText("X");
             sign=true;
             lock00=true;
         }
      }
      
      else if(event.getSource()==b01&&!lock01){
         System.out.println("b01");
         if(sign==true)
            {
                label01.setText("O");
                sign=false;
                lock01=true;                
            }
         else 
         {
             label01.setText("X");
             sign=true;
             lock01=true;                
         }
        }
      
      else if(event.getSource()==b02&&!lock02){
         System.out.println("b02");
         if(sign==true)
            {
                label02.setText("O");
                sign=false;
                lock02=true;                
            }
         else 
         {
             label02.setText("X");
             sign=true;
             lock02=true;                
         }
        }
      
      else if(event.getSource()==b10&&!lock10){
         System.out.println("b10");
         if(sign==true)
            {
                label10.setText("O");
                sign=false;
                lock10=true;                
            }
         else 
         {
             label10.setText("X");
             sign=true;
             lock10=true;                
         }
        }
      
      else if(event.getSource()==b11&&!lock11){
         System.out.println("b11");
         if(sign==true)
            {
                label11.setText("O");
                sign=false;
                lock11=true;                
            }
         else 
         {
             label11.setText("X");
             sign=true;
             lock11=true;                
         }
        }
      
      else if(event.getSource()==b12&&!lock12){
         System.out.println("b12");
         if(sign==true)
            {
                label12.setText("O");
                sign=false;
                lock12=true;                
            }
         else 
         {
             label12.setText("X");
             sign=true;
             lock12=true;                
         }
        }
      
      else if(event.getSource()==b20&&!lock20){
         System.out.println("b20");
         if(sign==true)
            {
                label20.setText("O");
                sign=false;
                lock20=true;                
            }
         else 
         {
             label20.setText("X");
             sign=true;
             lock20=true;                
         }
        }
      
      else if(event.getSource()==b21&&!lock21){
         System.out.println("b21");
         if(sign==true)
            {
                label21.setText("O");
                sign=false;
                lock21=true;                
            }
         else 
         {
             label21.setText("X");
             sign=true;
             lock21=true;                
         }
        }
      
      else if(event.getSource()==b22&&!lock22){
         System.out.println("b22");
         if(sign==true)
            {
                label22.setText("O");
                sign=false;
                lock22=true;                
            }
         else 
         {
             label22.setText("X");
             sign=true;
             lock22=true;                
         }
        }
      
      }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}