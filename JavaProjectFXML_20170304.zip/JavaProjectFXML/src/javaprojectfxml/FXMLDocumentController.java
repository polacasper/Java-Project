/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaprojectfxml;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;

/**
 *
 * @author Pola Casper
 */
public class FXMLDocumentController implements Initializable {

    private static boolean soundFlag = true;
    public boolean sign;
    public boolean lock00, lock01, lock02, lock10, lock11, lock12, lock20, lock21, lock22;

    public static String savedUsername;
    public static int conResponse;
    
    @FXML
    private Button single, multi, hall, settings, logout, back, back2, sound, label, signin, signup, newgame, easy, cancel, confirm;    
    
    @FXML
    private Image image;
            
    @FXML
    private TextField username, newuser;
    
    @FXML
    private PasswordField password, newpassword, newpassword2;
    
    
    @FXML
    private VBox vbox;
    
    @FXML
    private Button b00, b01, b02, b10, b11, b12, b20, b21, b22;
    
    @FXML
    private Label label00, label01, label02, label10, label11, label12, label20, label21, label22, labelresult, warning;
    
    @FXML
    private Label warning2;
    
    Stage stage;
    Parent root;

    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        if (event.getSource() == signin) {
            LoginClass.connectStart();
            savedUsername = username.getText();
            if(LoginClass.login(username.getText(), password.getText()))
            {
            stage = (Stage) signin.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Play.fxml"));
            }
            else if(username.getText().isEmpty() || password.getText().isEmpty())
            {
                System.out.println("Empty entry!");
                warning.setText("Please enter username and password.");
            }
            else
            {
                System.out.println("Wrong entry");
                warning.setText("Wrong username or password.");
            }
            
        }else if (event.getSource() == signup) {
            stage = (Stage) signup.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Register.fxml"));
        }else if (event.getSource() == confirm) {
            if (newuser.getText().isEmpty() || newpassword.getText().isEmpty() || newpassword2.getText().isEmpty()){warning2.setText("Empty Fields! Please fill all fields.");}
            else if (newuser.getText().contains(",") || newuser.getText().contains(";") || newuser.getText().contains("&") || newuser.getText().contains("!") || newuser.getText().contains("<") || newuser.getText().contains(">") || newuser.getText().contains("^") || newuser.getText().contains("/") || newuser.getText().contains("\\")){warning2.setText("Username or Password can not contain special charachter (, ; \\ / < > ! & ^)");}
            else if (newpassword.getText().contains(",") || newpassword.getText().contains(";") || newpassword.getText().contains("&") || newpassword.getText().contains("!") || newpassword.getText().contains("<") || newpassword.getText().contains(">") || newpassword.getText().contains("^") || newpassword.getText().contains("/") || newpassword.getText().contains("\\")){warning2.setText("Username or Password can not contain special charachter (, ; \\ / < > ! & ^)");}
            else if (!Objects.equals(newpassword.getText(), newpassword2.getText())){warning2.setText("Passwords don't match! Please reenter your passwords.");}
            else
            {
                RegisterClass.connectStart();
                if (RegisterClass.register(newuser.getText(), newpassword.getText(), newpassword2.getText())== false)
                {
                    System.out.println("okkkkkkkk");
                    warning2.setText("Username already exists!");
                }
                else
                {
                    stage = (Stage) confirm.getScene().getWindow();
                    root = FXMLLoader.load(getClass().getResource("Play.fxml"));
                }
                RegisterClass.connectClose();
            }
         }else if (event.getSource() == cancel || event.getSource() == back2) {
            stage = (Stage) cancel.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        } else if (event.getSource() == single) {
            stage = (Stage) single.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Difficulty.fxml"));
        } else if (event.getSource() == easy) {
            stage = (Stage) easy.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        } else if (event.getSource() == multi) {
            stage = (Stage) multi.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Player2.fxml"));
        } else if (event.getSource() == back) {
            stage = (Stage) back.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Play.fxml"));
        } else if (event.getSource() == hall) {
            stage = (Stage) hall.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("PlayerList.fxml"));
        } else if (event.getSource() == settings) {
            stage = (Stage) settings.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
            //FXMLLoader.
            if (soundFlag) {
                label.setText("Sound on");
                System.out.println(soundFlag);
            } else if (!soundFlag) {
                label.setText("Sound off");
                System.out.println(soundFlag);
            }
        } else if (event.getSource() == sound) {
            soundFlag = !soundFlag;
            if (soundFlag) {
                label.setText("Sound on");
            } else if (!soundFlag) {
                label.setText("Sound off");
            }
        } else if (event.getSource() == logout) {
            LogoutClass.connectStart();
            LogoutClass.logout(savedUsername);
            LogoutClass.connectClose();
            stage = (Stage) logout.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        } else if (event.getSource() == newgame) {
            stage = (Stage) newgame.getScene().getWindow();
            root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        }

        //create a new scene with root and set the stage
        if (root != null) {
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    public void Game(ActionEvent event) throws RuntimeException {
        if (event.getSource() == b00 && !lock00) {
            System.out.println("b00");
            if (sign == true) {
                label00.setText("O");
                sign = false;
                lock00 = true;
            } else {
                label00.setText("X");
                sign = true;
                lock00 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b01 && !lock01) {
            System.out.println("b01");
            if (sign == true) {
                label01.setText("O");
                sign = false;
                lock01 = true;
            } else {
                label01.setText("X");
                sign = true;
                lock01 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b02 && !lock02) {
            System.out.println("b02");
            if (sign == true) {
                label02.setText("O");
                sign = false;
                lock02 = true;
            } else {
                label02.setText("X");
                sign = true;
                lock02 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b10 && !lock10) {
            System.out.println("b10");
            if (sign == true) {
                label10.setText("O");
                sign = false;
                lock10 = true;
            } else {
                label10.setText("X");
                sign = true;
                lock10 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b11 && !lock11) {
            System.out.println("b11");
            if (sign == true) {
                label11.setText("O");
                sign = false;
                lock11 = true;
            } else {
                label11.setText("X");
                sign = true;
                lock11 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b12 && !lock12) {
            System.out.println("b12");
            if (sign == true) {
                label12.setText("O");
                sign = false;
                lock12 = true;
            } else {
                label12.setText("X");
                sign = true;
                lock12 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b20 && !lock20) {
            System.out.println("b20");
            if (sign == true) {
                label20.setText("O");
                sign = false;
                lock20 = true;
            } else {
                label20.setText("X");
                sign = true;
                lock20 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b21 && !lock21) {
            System.out.println("b21");
            if (sign == true) {
                label21.setText("O");
                sign = false;
                lock21 = true;
            } else {
                label21.setText("X");
                sign = true;
                lock21 = true;
            }
            success('X');
            success('O');
        } else if (event.getSource() == b22 && !lock22) {
            System.out.println("b22");
            if (sign == true) {
                label22.setText("O");
                sign = false;
                lock22 = true;
            } else {
                label22.setText("X");
                sign = true;
                lock22 = true;
            }
            success('X');
            success('O');
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    public void success(char ch) {
        if (ch == label00.getText().charAt(0)) {
            if (ch == label10.getText().charAt(0) && ch == label20.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            } else if (ch == label01.getText().charAt(0) && ch == label02.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            } else if (ch == label11.getText().charAt(0) && ch == label22.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            }
        }
        if (ch == label22.getText().charAt(0)) {
            if (ch == label20.getText().charAt(0) && ch == label21.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            } else if (ch == label12.getText().charAt(0) && ch == label02.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            }
        }
        if (ch == label11.getText().charAt(0)) {
            if (ch == label20.getText().charAt(0) && ch == label02.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            } else if (ch == label10.getText().charAt(0) && ch == label12.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            } else if (ch == label01.getText().charAt(0) && ch == label21.getText().charAt(0)) {
                labelresult.setText("You Win!");
                b00.setDisable(true);
                b01.setDisable(true);
                b02.setDisable(true);
                b10.setDisable(true);
                b11.setDisable(true);
                b12.setDisable(true);
                b20.setDisable(true);
                b21.setDisable(true);
                b22.setDisable(true);
            }
        }
    }
}
