package javaprojectfxml;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import oracle.jdbc.driver.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javaprojectfxml.LoginClass.pst;
import org.apache.derby.jdbc.ClientDriver;
import org.postgresql.Driver;

/**
 *
 * @author Pola Casper
 */
public class RegisterClass {

    /**
     * @param args the command line arguments
     */
    
   static Connection con;
   static PreparedStatement pst;
   static ResultSet rs;
   static String name;
   static String pass;
   public static String[] namesArray;
   public static String[] passArray;
   static int k;
   static boolean existFlag = false;
   public static boolean returnVal;
    
    public static void connectStart()
    {
        try {
                //DriverManager.registerDriver(new OracleDriver());
                con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "postgres");
                System.out.println("OK Start");
       } catch (SQLException ex) {
           Logger.getLogger(RegisterClass.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
     public static void connectClose()
    {
       try {
           pst.close();
           con.close();
           System.out.println("OK Close");
       } catch (SQLException ex) {
           Logger.getLogger(RegisterClass.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
   
    public static boolean register(String newUsername, String newPassword, String newPassword2)
    {
           try {
               pst = con.prepareStatement("Select count(playername) from tictactoe",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
               rs = pst.executeQuery();
               
               if(rs.next()){k = rs.getInt(1);}
               System.out.println("Count(playername) = "+k);
               
               namesArray = new String[k];
               pst = con.prepareStatement("Select playername from tictactoe",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
               rs = pst.executeQuery();
               int i=0;
               while(rs.next())
               {
                   name = rs.getString(1);
                   namesArray[i]=name;
                   System.out.println(namesArray[i]);
                   i++;
               }
               
           } catch (SQLException ex) {
               Logger.getLogger(LoginClass.class.getName()).log(Level.SEVERE, null, ex);
           }
           
           for(String names : namesArray)
               System.out.println(names);
           
           for(String str : namesArray)
           {
               if (newUsername.equalsIgnoreCase(str.trim()))
               {
                   returnVal = false;
                   break;
               }
               
               else
               {
                   try {
                       pst = con.prepareStatement("insert into tictactoe (playername, playerpassword, playerstatus) values (?, ?, true)",ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                       pst.setString(1, newUsername);
                       pst.setString(2, newPassword);
                       pst.executeQuery();
                   } catch (SQLException ex) {
                       Logger.getLogger(RegisterClass.class.getName()).log(Level.SEVERE, null, ex);
                   }
                   returnVal = true;
               }           
        }
           return returnVal;
    }
}